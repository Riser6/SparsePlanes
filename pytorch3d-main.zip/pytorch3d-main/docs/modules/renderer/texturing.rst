texturing
===========================

.. automodule:: pytorch3d.renderer.mesh.texturing
    :members:
    :undoc-members:
    