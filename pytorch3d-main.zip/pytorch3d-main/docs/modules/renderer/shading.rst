shading
===========================

.. automodule:: pytorch3d.renderer.mesh.shading
    :members:
    :undoc-members:
    
