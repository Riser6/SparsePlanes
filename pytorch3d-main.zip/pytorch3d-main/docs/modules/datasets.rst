pytorch3d.datasets
===========================

Dataset loaders for datasets including ShapeNetCore.

.. automodule:: pytorch3d.datasets
    :members:
    :undoc-members:
    :show-inheritance:
