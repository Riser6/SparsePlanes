# Acknowledgements

Thank you to Keenan Crane for allowing the cow mesh model to be used freely in the public domain.

###### Source: http://www.cs.cmu.edu/~kmcrane/Projects/ModelRepository/
